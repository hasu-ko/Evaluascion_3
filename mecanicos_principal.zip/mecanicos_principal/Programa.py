from Crud_Mecanico import *
from clases_mecanicos import *
from termcolor import colored
import maskpass

class Menu:

    def __init__(self):
        self.__crud_mecanico = CrudMecanico()
        self.__crud_sesion = CrudUsuario()
        self.__crud_cliente = CrudCliente()
        self.__crud_rol = CrudRol()
        self.__crud_vehiculo = CrudVehiculo()
        self.__crud_trabajo = CRUDTrabajo()

    def opciones(self):
        interfaz = Main()
        print(colored(" ╔══════════════════════════════════════════════════════════════════╗ ")) 
        print(colored(" ║    ⚙️      ---  Bienvenido al Taller Mecánico ---       ⚙️      ║", 'green', 'on_black', attrs=['bold'] ))
        print(colored(" ╠══════════════════════════════════════════════════════════════════╣ "))
        print(colored(" ╠══════════════════════════════════════════════════════════════════╣ "))
        print(colored(" ║   Seleccione su Acción al Iniciar Sesión:                        ║ \n", 'yellow', attrs=['bold']))
        print(colored(" ║   1. Iniciar Sesión como Administrador                           ║ ", 'red', attrs=['bold']))
        print(colored("--------------------------------------------------------------------║", 'yellow'))
        print(colored(" ║   2. Iniciar Sesión como Secretaria                              ║ ", 'red', attrs=['bold']))
        print(colored("--------------------------------------------------------------------║", 'yellow'))
        print(colored(" ║   3. Iniciar Sesión como Mecánico                                ║ ", 'red', attrs=['bold']))
        print(colored("--------------------------------------------------------------------║", 'yellow'))
        print(colored(" ║   0. Salir del Programa                                          ║ ",attrs=['bold']))
        print(colored(" ╚══════════════════════════════════════════════════════════════════╝ "))
        print(colored(" ╚══════════════════════════════════════════════════════════════════╝"))
        while True:
            try:
                opcion = int(input('Ingrese su opción: '))
                if opcion in [0, 1, 2, 3]:
                    return opcion
                else:
                    print(colored('La opción ingresada no es válida', 'red'))
            except ValueError:
                print(colored('La opción ingresada no es válida', 'red'))
    
    def imprimir_menu(self):
        interfaz = Main()

    def iniciar(self):
        interfaz = Main()
        while True:
            opcion = self.opciones()
            if opcion == 1:
                self.iniciar_sesion(interfaz, opcion)
            elif opcion == 2:
                self.iniciar_sesion(interfaz, opcion)
            elif opcion == 3:
                self.iniciar_sesion(interfaz, opcion)
            elif opcion == 0:
                print("Hasta La Proxima...")
                break
            else:
                print("Opcion ingresada no valida\n Intentelo Nuevamente")

    def iniciar_sesion(self, interfaz, opcion):
        nombre = input('Ingrese el nombre de usuario: ')
        clave = maskpass.askpass('Ingrese la clave: ')
    
        if not nombre or not clave:
            print("Por favor, ingrese tanto el nombre de usuario como la clave.")
            return

        if opcion == 1 and ((nombre == "secre" or clave == "secre") or (nombre == "mecan" or clave == "mecanico")):
            print(colored("Se equivocó de sesión. No debería estar en esta interfaz.", 'red'))
            return
        elif opcion == 2 and ((nombre == "admin" or clave == "admin") or (nombre == "mecan" or clave == "mecan")):
            print(colored("Se equivocó de sesión. No debería estar en esta interfaz.", 'red'))
            return
        elif opcion == 3 and ((nombre == "admin" or clave == "admin") or (nombre == "secre" or clave == "secre")):
            print(colored("Se equivocó de sesión. No debería estar en esta interfaz.", 'red'))
            return
        else:
            print("Credenciales correctas!")

        crud = CrudUsuario()
        usuario = crud.buscar_usuario(nombre)

        if usuario is not None and usuario.validar_clave(clave):
            print('Bienvenido  ({})!\n'.format(
                usuario.obtener_rol().obtener_nombre_rol()
            ))

            id_rol = usuario.obtener_rol().obtener_id()

            if id_rol == 1:
                self.menu_administrador()
            elif id_rol == 2:
                self.menu_secretaria()
            elif id_rol == 3:
                self.menu_mecanico()

                

    def menu_administrador(self):
        while True:
                print(colored(" ╔══════════════════════════════════════════════════════════════════╗ ")) 
                print(colored(" ║         ---- Acciones disponibles para Administradores ----      ║", 'red',attrs=['bold']))
                print(colored(" ╠══════════════════════════════════════════════════════════════════╣ \n"))
    
                print(colored('--- Gestionar usuarios --- ', 'yellow'))
                print()
                print(' 1. Crear usuario')
                print("-----------------------------║")
                print(' 2. Listar usuarios')
                print("-----------------------------║")
                print(' 3. Reestablecer clave')
                print("-----------------------------║")
                print(' 4. Eliminar usuario\n')
                print("-----------------------------║")

                print(colored('--- Gestionar mecánicos ---', 'yellow'))
                print()
                print(' 5. Listar mecánicos')
                print("-----------------------------║")
                print(' 6. Crear mecánico')
                print("-----------------------------║")
                print(' 7. Cambiar honorario')
                print("-----------------------------║")
                print(' 8. Eliminar mecánico')
                print("-----------------------------║")
                print(' 0. Salir de la sesion')

                try:
                    opcion = int(input(colored("\nIngrese una opción: ", 'cyan')))
                    if opcion == 1:
                        self.mostrar_usuario()          
                    elif opcion == 2:
                        self.crear_nuevo_usuario()
                    elif opcion == 3:
                        self.reestablecer_clave_usuario()
                    elif opcion == 4:
                        self.eliminar_usuario_por_rut()
                    elif opcion == 5:
                        self.mostrar_mecanico()
                    elif opcion == 6:
                        self.agregar_mecanico()
                    elif opcion == 7:
                        self.modificar_sueldo_mecanico()
                    elif opcion == 8:
                        self.eliminar_mecanico()
                    elif opcion == 0:
                        print(colored("\nSesión cerrada. Hasta la próxima ('Administrador')", 'red',attrs=['bold']))
                        self.opciones()
                        break
                except ValueError:
                    print("Ingrese Datos Numericos...\nIntentelo Nuevamente")
                          
                    
                              
    def menu_secretaria(self):
        while True:
                print(colored(" ╔══════════════════════════════════════════════════════════════════╗ ")) 
                print(colored(" ║         ---- Acciones disponibles para Secretarias ----          ║", 'red',attrs=['bold']))
                print(colored(" ╠══════════════════════════════════════════════════════════════════╣ \n"))
    
                print(colored('--- Gestionar clientes --- ', 'yellow'))
                print()
                print(' 1. crear cliente')
                print("-----------------------------║")
                print(' 2. listar cliente')
                print("-----------------------------║")
                print(' 3. cambiar telefono')
                print("-----------------------------║")
                print(' 4. Eliminar cliente\n')
                print("-----------------------------║")

                print(colored('--- Gestionar vehiculos ---', 'yellow'))
                print()
                print(' 5. crear vehiculo')
                print("-----------------------------║")
                print(' 6. listar vehiculo')
                print("-----------------------------║")
                print(' 7. Eliminar vehiculo')
                print("-----------------------------║")
                print(' 0. Salir de la sesion')
                
                try:
                    opcion = int(input(colored("\nIngrese una opción: ", 'cyan')))
                    if opcion == 1:
                        self.agregar_clientes()
                    elif opcion == 2:
                        self.mostrar_cliente()
                    elif opcion == 3:
                        self.modificar_telefono()
                    elif opcion == 4:
                        self.eliminar_cliente()
                    elif opcion == 5:
                        self.crear_vehiculo()
                    elif opcion == 6:
                        self.lista_de_vehiculos()
                    elif opcion == 7:
                        self.eliminar_vehiculo()
                    elif opcion == 0:
                        print(colored("\nSesión cerrada. Hasta la próxima ('Secretaria')", 'red',attrs=['bold']))
                        self.opciones()
                        break
                except ValueError:
                    print("Ingrese Datos Numericos...\nIntentelo Nuevamente")
    
    def menu_mecanico(self):
        interfaz = Main()

        while True:
                print(colored(" ╔══════════════════════════════════════════════════════════════════╗ ")) 
                print(colored(" ║         ---- Acciones disponibles para Mecanicos ----            ║", 'red',attrs=['bold']))
                print(colored(" ╠══════════════════════════════════════════════════════════════════╣ \n"))
    
                print(colored('--- Gestionar trabajos --- ', 'yellow'))
                print()
                print(' 1. crear Trabajo')
                print("-----------------------------║")
                print(' 2. listar Trabajo')
                print("-----------------------------║")
                print(' 3. buscar Trabajo')
                print("-----------------------------║")
                print(' 4. agregar Mecanico')
                print("-----------------------------║")
                print(' 5. cambiar Estado y Reparaciones ')
                print("-----------------------------║")
                print(' 0. Salir de la sesion \n')

                try:
                    opcion = int(input(colored("\nIngrese una opción: ", 'cyan')))
                    if opcion == 1:
                        self.crear_trabajo()
                    elif opcion == 2:
                        self.listar_trabajos()
                    elif opcion == 3:
                        self.buscar_trabajo()
                    elif opcion ==5:
                        self.mostrar_trabajos(interfaz.obtener_trabajos())
                    elif opcion == 0:
                        print(colored("\nSesión cerrada. Hasta la próxima ('Mecanico')", 'red',attrs=['bold']))
                        self.opciones()
                        break 
                    else:
                        print("Opción no válida. Inténtalo nuevamente.")

                except ValueError:
                    print("Ingrese Datos Numericos\nIntentelo Nuevamente")

    def crear_nuevo_usuario(self):
        nombre_usuario = input("Ingrese el nombre de usuario: ")
        clave = input("Ingrese la clave: ")
        nombre_rol = input("Ingrese el nombre del rol: ")  
        descripcion_rol = input("Ingrese la descripción del rol: ") 
        rut_mecanico = input("Ingrese el RUT del mecánico (opcional): ")
        rol = Rol(id=None, nombre_rol=nombre_rol, descripcion=descripcion_rol) 

        if rut_mecanico:
            usuario = Usuario(nombre_usuario, clave, rol, rut_mecanico)
        else:
            usuario = Usuario(nombre_usuario, clave, rol)

        self.__crud_sesion.crear_usuario(usuario, clave)

                    
    
    def mostrar_usuario(self):
        print("Lista de Usuarios: \n")
        usuarios = self.__crud_sesion.obtener_usuarios()
        roles = self.__crud_rol.mostrar_rol()

        for i, (usuario, rol) in enumerate(zip(usuarios, roles), start=1):
            print(f'''
                ╔════════════════════════════════════════════════════════╗
                Usuario {i}:
                ID_Rol: {rol.obtener_id()}
                    Nombre: {usuario.obtener_nombre()}
                    Clave: {usuario.obtener_clave()}
                    RUT: {usuario.obtener_rut()}

                Rol:
                    Nombre_Rol: {rol.obtener_nombre_rol()}
                    Descripcion_Rol: {rol.obtener_descripcion()}
                
                ╚════════════════════════════════════════════════════════╝
            ''')
            print()
    def eliminar_usuario_por_rut(self):
        rut_a_eliminar = input('Ingrese el RUT del usuario que desea eliminar: ')

        if self.__crud_sesion.buscar_usuario_por_rut(rut_a_eliminar):
            confirmacion = input(colored(f"¿Está seguro de que desea eliminar al Usuario con RUT {rut_a_eliminar}? (SI/NO)\n ", 'red')).lower()
            if confirmacion == 'si':
                if self.__crud_sesion.eliminar_usuario_por_rut(rut_a_eliminar):
                    print(colored(f'Usuario con RUT {rut_a_eliminar} eliminado exitosamente.', 'green'))
            else:
                print(colored("Operación cancelada.", 'yellow'))
        else:
            print(colored(f'Error: No se encontró un usuario con el RUT {rut_a_eliminar}.', 'red'))

    
    def reestablecer_clave_usuario(self):
        rut = input("Ingrese el RUT del usuario: ")
        clave = maskpass.askpass('Ingrese la clave: ')
        if self.__crud_sesion.reestablecer_clave_por_rut(rut, clave):
            print("Clave reestablecida con éxito.")
        else:
            print(f"Usuario con RUT {rut} no encontrado.")

    def agregar_clientes(self):
        print("Ingrese Cliente...\n")
        rut = input("Ingrese RUT (formato XXX-9):\n")
        partes = rut.split('-')
        if len(partes) != 2 or not partes[0].isdigit() or not partes[1].isdigit():
            print("Ingrese un RUT válido (formato XXX-9).\nInténtelo De Nuevo")
            return
                
        nombre = input("Ingrese Un Nombre\n")
        apellido = input("Ingrese Un Apellido\n")
        if not nombre or not apellido:
            print("Debe ingresar tanto el nombre como el apellido. Intentelo de nuevo.")
            return
            
        try:
            telefono = int(input("Ingrese telefono:\n"))
            if telefono < 0:
                print("Ingrese Solo Valores Positivos")
                return
        except ValueError:
            print("Ingrese solo datos numéricos. Inténtelo de nuevo.")
        
        cliente = Cliente(rut, nombre, apellido, telefono)
        self.__crud_cliente.agregar_clientes(cliente)

    def mostrar_cliente(self):
        print("Lista de Clientes: \n")
        clientes = self.__crud_cliente.obtener_cliente()
        for i, cliente in enumerate(clientes, start=1):
            print(f'''
                    ╔════════════════════╗
                    Datos Cliente {i}:
                    Rut    :  {cliente.obtener_rut()}
                    Nombre :  {cliente.obtener_nombre()} 
                    Apellido: {cliente.obtener_apellido()}
                    Telefono: {cliente.obtener_telefono()}
                    ╚════════════════════╝''')
    
    def modificar_telefono(self):
        try:
            rut_cliente = input("Ingrese el RUT del Cliente que desea modificar: ")
            telefono_nuevo = int(input("Ingrese el nuevo Numero Telefono:\n "))
        except ValueError:
            print("Ingrese Solamente Numeros! \nIntentelo De Nuevo")
            return

        mecanico = self.__crud_cliente.buscar_cliente(rut_cliente)
        if mecanico:
            self.__crud_cliente.modificar_telefono(rut_cliente, telefono_nuevo)
            print(f"Telefono del RUT : {rut_cliente} Del Cliente modificado con éxito!")
        else:
            print(f"No se encontró un mecánico con el RUT {rut_cliente}\nIntentelo De Nuevo")

    def eliminar_cliente(self):
        try:
            rut_eliminar = input("Ingrese el RUT del Cliente que desea eliminar: ")
            cliente_existente = self.__crud_cliente.buscar_cliente(rut_eliminar)
        except ValueError:
            print("ERROR: Ingrese Datos Numericos\n Intentelo De Nuevo")
            return

        if cliente_existente:
            confirmacion = input(f"¿Está seguro de que desea eliminar al Cliente con RUT {rut_eliminar}? (SI/NO)\n ").lower()
            if confirmacion == 'si':
                self.__crud_cliente.eliminar_cliente(rut_eliminar)
                print("Cliente eliminado con éxito.")
            else:
                print("Operación cancelada.")
        else:
            print(f"No se encontró un mecánico con el RUT {rut_eliminar}.")

        

    def agregar_mecanico(self):
                print("Ingrese Mecanico...\n")
                rut = input("Ingrese RUT (formato XXX-9):\n")
                partes = rut.split('-')
                if len(partes) != 2 or not partes[0].isdigit() or not partes[1].isdigit():
                    print("Ingrese un RUT válido (formato XXX-9).\nInténtelo De Nuevo")
                    return
                    
                nombre = input("Ingrese Un Nombre\n")
                apellido = input("Ingrese Un Apellido\n")
                if not nombre or not apellido:
                    print("Debe ingresar tanto el nombre como el apellido. Intentelo de nuevo.")
                    return
                
                try:
                    honorario = int(input("Ingrese Honorario:\n"))
                    if honorario < 0:
                        print("Ingrese Solo Valores Positivos")
                        return
                except ValueError:
                    print("Ingrese solo datos numéricos. Inténtelo de nuevo.")
                mec = Mecanico(rut, nombre, apellido, honorario)
                self.__crud_mecanico.agregar_mecanicos(mec)

    

    def crear_vehiculo(self):
        while True:
            patente = input("Ingrese patente del vehiculo: \n->").lower()
            if not patente:
                print("Se debe ingresar una patente")
            else:
                break

        while True:
            marca = input("Ingrese marca del vehiculo: \n->").lower()
            if not marca:
                print("Se debe ingresar una marca")
            else:
                break

        while True:
            modelo = input("Ingrese modelo del vehiculo: \n->").lower()
            if not modelo:
                print("Se debe ingresar un modelo")
            else:
                break

        while True:
            try:
                año = int(input("Ingrese año del vehiculo: \n->"))
                if not año:
                    print("Se debe ingresar un año")
                else:
                    break
            except ValueError:
                print("Se debe ingresar El Año En Formato (YYYY)")

        while True:
            rut = input("Ingrese Rut del propietario del vehiculo: \n-> ").lower()
            if not rut:
                print("Se debe ingresar el rut del propietario del vehiculo...")
            else:
                if self.__crud_cliente.buscar_cliente(rut):
                    nuevo_vehiculo = Vehiculo(patente, marca, modelo, año, rut)
                    self.__crud_vehiculo.crear_vehiculo(nuevo_vehiculo)
                    print("Vehículo creado exitosamente.")
                    break
                else:
                    print("El cliente con el Rut ingresado no existe. Por favor, cree el cliente primero.")
        
    def lista_de_vehiculos(self):
        print("Lista de Vehículos encontrados:\n")
        vehiculos = self.__crud_vehiculo.obtener_vehiculos()
        if not vehiculos:
            print("No se encuentran vehículos registrados...")
        else:
            for i, vehiculo_data in enumerate(vehiculos, start=1):
                print(f'''
            ╔════════════════════════════════╗
            Datos Vehículo {i}:
            Patente   : {vehiculo_data[0]}
            Marca     : {vehiculo_data[1]}
            Modelo    : {vehiculo_data[2]}
            Año       : {vehiculo_data[3]}
            Rut Cliente: {vehiculo_data[4]}
            ╚════════════════════════════════╝''')
        print()

    def eliminar_vehiculo(self):
        try:
            patente_vehiculo_eliminar = input('Ingrese la patente del vehículo a eliminar: ')
            trabajos_asociados = self.__crud_trabajo.obtener_trabajos(patente_vehiculo_eliminar)

            if trabajos_asociados:
                print("Existen trabajos asociados al vehículo:")
                for trabajo in trabajos_asociados:
                    print(f"- ID Trabajo: {trabajo.obtener_id()}, Fecha de Inicio: {trabajo.obtener_fecha_inicio()}")

                confirmacion = input("¿Está seguro que desea eliminar el vehículo con patente '{}' y los trabajos asociados? (Sí/No): ".format(patente_vehiculo_eliminar)).lower()

                if confirmacion == 'si' or confirmacion == 's':
                    for trabajo in trabajos_asociados:
                        self.__crud_trabajo.eliminar_trabajo(trabajo.obtener_id())

                    self.__crud_vehiculo.eliminar_vehiculo(patente_vehiculo_eliminar)
                    print(f'Vehículo con patente {patente_vehiculo_eliminar} y trabajos asociados eliminados exitosamente.')
                else:
                    print(f'La eliminación del vehículo con patente {patente_vehiculo_eliminar} y trabajos asociados ha sido cancelada.')
            else:
                self.__crud_vehiculo.eliminar_vehiculo(patente_vehiculo_eliminar)
                print(f'Vehículo con patente {patente_vehiculo_eliminar} eliminado exitosamente.')

        except Exception as ex:
            print('Error: {}'.format(ex))

    def crear_trabajo(self):
        try:
            while True:
                patente = input("Ingrese la patente del vehículo existente: ").lower()
                vehiculo_existente = self.__crud_vehiculo.buscar_vehiculo(patente)
                if vehiculo_existente:
                    break
                else:
                    print("La patente ingresada no existe. Inténtelo de nuevo.")
            fecha_inicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
            fecha_entrega = input("Ingrese la fecha de entrega (YYYY-MM-DD): ")
            estado_inicial = input("Ingrese el estado inicial: ")
            detalles_reparacion = input("Ingrese los detalles de la reparación: ")
            costo_total_repuestos = float(input("Ingrese el costo total de repuestos: "))

            nuevo_trabajo = Trabajo(
                fecha_inicio=fecha_inicio,
                fecha_entrega=fecha_entrega,
                estado_inicial=estado_inicial,
                detalles_reparacion=detalles_reparacion,
                costo_total_repuestos=costo_total_repuestos,
                mecanicos=[],  
                vehiculos=[vehiculo_existente]
            )

            nuevo_trabajo.asignar_vehiculo(vehiculo_existente)

            self.__crud_trabajo.crear_trabajo(nuevo_trabajo)

            print("Trabajo creado exitosamente.")
        except Exception as e:
            print(f"Error al crear el trabajo: {e}")

    def listar_trabajos(self):
        try:
            trabajos = self.__crud_trabajo.listar_trabajos()
            if not trabajos:
                print("No hay trabajos registrados...")
            else:
                for i, trabajo in enumerate(trabajos, start=1):
                    print(f"Trabajo {i}:")
                    print(f"Fecha de inicio: {trabajo.obtener_fecha_inicio()}")
                    print(f"Fecha de entrega: {trabajo.obtener_fecha_entrega()}")
                    print(f"Estado inicial: {trabajo.obtener_estado_inicial()}")
                    print(f"Detalles de la reparación: {trabajo.obtener_detalles_reparaciones()}")
                    print(f"Costo total de repuestos: {trabajo.obtener_costo_total_reparaciones()}")
                    print("Mecánicos:")
                    for mecanico in trabajo.obtener_mecanicos():
                        print(f"  - {mecanico}")
                    print("Vehículo:")
                    vehiculo = trabajo.obtener_vehiculos()
                    print(f"  - Patente: {vehiculo.obtener_patente()}")
                    print(f"  - Marca: {vehiculo.obtener_marca()}")
                    print(f"  - Modelo: {vehiculo.obtener_modelo()}")
                    print(f"  - Año: {vehiculo.obtener_año()}")
                    print(f"  - Rut Cliente: {vehiculo.obtener_rut()}")
                    print("\n")
        except Exception as e:
            print(f"Error al listar trabajos: {e}")

    def buscar_trabajo(self):
        try:
            patente_ingresada = input("Ingrese la patente del vehículo: ").lower()
            trabajos_encontrados = self.listar_trabajos()

            if trabajos_encontrados:
                trabajos_por_patente = [trabajo for trabajo in trabajos_encontrados if trabajo.obtener_vehiculos().obtener_patente() == patente_ingresada]

                if trabajos_por_patente:
                    for trabajo_encontrado in trabajos_por_patente:
                        print("\nDatos del trabajo:")
                        print(f"ID de Trabajo: {trabajo_encontrado.obtener_id()}")
                        print(f"Fecha de Inicio: {trabajo_encontrado.obtener_fecha_inicio()}")
                        print(f"Fecha de Entrega: {trabajo_encontrado.obtener_fecha_entrega()}")
                        print(f"Estado Inicial: {trabajo_encontrado.obtener_estado_inicial()}")
                        print(f"Detalles de la Reparación: {trabajo_encontrado.obtener_detalles_reparaciones()}")
                        print(f"Costo Total de Repuestos: {trabajo_encontrado.obtener_costo_total_reparaciones()}")

                        # Mostrar datos del cliente asociado al trabajo
                        cliente = trabajo_encontrado.obtener_cliente()
                        print("\nDatos del Cliente:")
                        print(f"Rut: {cliente.obtener_rut()}")
                        print(f"Nombre: {cliente.obtener_nombre()}")
                        print(f"Apellido: {cliente.obtener_apellido()}")
                        print(f"Teléfono: {cliente.obtener_telefono()}")

                        # Mostrar datos del vehículo asociado al trabajo
                        vehiculo = trabajo_encontrado.obtener_vehiculos()
                        print("\nDatos del Vehículo:")
                        print(f"Patente: {vehiculo.obtener_patente()}")
                        print(f"Marca: {vehiculo.obtener_marca()}")
                        print(f"Modelo: {vehiculo.obtener_modelo()}")
                        print(f"Año: {vehiculo.obtener_año()}")

                        # Mostrar mecánicos asociados al trabajo (puedes ajustar según tu lógica)
                        mecanicos = trabajo_encontrado.obtener_mecanicos()
                        print("\nMecánicos Asociados:")
                        if mecanicos:
                            for mecanico in mecanicos:
                                print(f"Rut Mecánico: {mecanico.obtener_rut()}")
                                print(f"Nombre Mecánico: {mecanico.obtener_nombre()}")
                                print(f"Apellido Mecánico: {mecanico.obtener_apellido()}")
                                print(f"Honorario Mecánico: {mecanico.obtener_honorario()}")
                                print("\n")
                        else:
                            print("No hay mecánicos asociados a este trabajo.")
                else:
                    print(f"No se encontró ningún trabajo con la patente {patente_ingresada}.")
            else:
                print("No hay trabajos registrados.")

        except Exception as e:
            print(f"Error al mostrar los datos del trabajo: {e}")





    def agregar_reparaciones(self, main):
        while True:
            patente = input("Ingrese patente del vehiculo: \n-> ").lower()
            vehiculo = main.encontrar_vehiculos(patente)
            if vehiculo == None:
                print("El vehiculo no se encuentra registrado")
                print("Intentelo De Nuevo...")
                break
            else:
                fecha_inicio = input("Fecha ingreso del vehiculo (YYYY-MM-DD): ") 
                fecha_entrega = input("Fecha estimada de entrega (YYYY-MM-DD): ")
                while True:
                    estado_incial = input("Estado inicial del vehiculo: ")
                    if not estado_incial:
                        print("Se debe ingresar El estado inicial...")
                    else:
                        break
                while True:
                    detalles_reparacion = input("Detalles de la reparacion: \n-> ")
                    if not detalles_reparacion:
                        print("Se debe ingresar detalles De  La reparacion...")
                    else:
                        break
                while True:
                    try:
                        costo_total_repuestos = int(input("Costo total de  Los respuestos \n->"))
                        if costo_total_repuestos <= 0:
                            print("El costo debe ser un valor Positivo...")
                        else:
                            break
                    except ValueError:
                        print("Valor ingresado no valido...")
                mecanicos_asignados = []
                while True:
                    nombre_mecanico = input("Asigne mecanico al trabajo (nombre y apellido): ").strip().lower()
                    if not nombre_mecanico:
                        print("Se debe ingresar un nombre y apellido del mecánico...")
                    else:
                        mecanico_encontrado = None
                        for mecanico in main.obtener_mecanicos():
                            nombre_apellido = f"{mecanico.obtener_nombre().lower()} {mecanico.obtener_apellido().lower()}"
                            if nombre_mecanico == nombre_apellido:
                                mecanico_encontrado = mecanico
                                break
                    if mecanico_encontrado is None:
                        print("Mecánico no encontrado.")
                    else:
                        print("Mecánico asignado")
                        break
    
                    otro_mecanico = input("Desea agregar otro mecanico? si/no: ").lower()
                    if otro_mecanico != "si":
                        if not mecanicos_asignados:
                            print("Debes asignar al menos un mecánico.")
                        else:
                            break
            while True:
                vehiculo = input("Ingrese vehiculo : ").lower()
                if not vehiculo:
                    print("Se debe ingresar un vehiculo...")
                else:
                    break
            reparacion = Trabajo(fecha_inicio, fecha_entrega, estado_incial, detalles_reparacion, costo_total_repuestos, mecanicos_asignados, vehiculo)
            main.agregar_reparaciones(reparacion)

            costo_reparacion = reparacion.calcular_costo_total()
            print("El costo total de la reparacion es : $ {}".format(costo_reparacion))
            break
    
    def buscar_mecanico(self):
        try:
            rut_buscar = int(input("Ingrese el RUT del mecánico que desea buscar: "))
        except ValueError:
            print("Ingrese Datos Numericos\n Intentelo De Nuevo")
            return
        mecanico_encontrado = self.__crud_mecanico.buscar_mecanico(rut_buscar)
        if mecanico_encontrado:
            print("Mecánico encontrado:")
            print(f"Nombre: {mecanico_encontrado.obtener_nombre()}")
            print(f"Apellido: {mecanico_encontrado.obtener_apellido()}")
            print(f"Honorario: {mecanico_encontrado.obtener_honorario()}")
        else:
            print("Mecánico no encontrado.")


    def mostrar_mecanico(self):
        print("Lista de Mecánicos: \n")
        mecanicos = self.__crud_mecanico.obtener_mecanico()
        for i, mecanico in enumerate(mecanicos, start=1):
            print(f"Mecánico {i}:")
            print(f"RUT: {mecanico.obtener_rut()}")
            print(f"Nombre: {mecanico.obtener_nombre()}")
            print(f"Apellido: {mecanico.obtener_apellido()}")
            print(f"Honorario: {mecanico.obtener_honorario()}")
            print()

    def mostrar_vehiculos(self, vehiculos):
        if not vehiculos:
            print("No se encuentran vehiculos registrados...")
        else:      
            for vehiculo in vehiculos:
                print("")
                print(f"Patente : {vehiculo.obtener_patente()}")
                print(f"Marca : {vehiculo.obtener_marca()}")
                print(f"Modelo : {vehiculo.obtener_modelo()}")
                print(f"Año : {vehiculo.obtener_año()}")
                print(f"Cliente : {vehiculo.obtener_cliente()}")
                print(f"Telefono : {vehiculo.obtener_telefono()}")
                print("")
        
    def mostrar_trabajos(self, trabajos):
        if not trabajos:
            print("No se encuentran trabajos registrados...")
        else:
            for trabajo in trabajos:
                    print("Trabajo:")
                    print(f"Fecha inicio: {trabajo.obtener_fecha_inicio()}")
                    print(f"Fecha entrega: {trabajo.obtener_fecha_entrega()}")
                    print(f"Estado inicial: {trabajo.obtener_estado_iNnicial()}")
                    print(f"Detalles de reparaciones: {trabajo.obtener_detalles_reparaciones()}")
                    print(f"Costo total de repuestos: {trabajo.obtener_costo_total_reparaciones()}")
                    mecanicos_asignados = trabajo.obtener_mecanicos()
                    print("Mecánicos asignados: ")
            for mecanico in mecanicos_asignados:
                print(f"Nombre: {mecanico.obtener_nombre()} {mecanico.obtener_apellido()}")
                print(f"Honorario mecanico: {mecanico.obtener_honorario()}")
                print(f"Vehiculo: {trabajo.obtener_vehiculos()}")
                print(f"Costo total de reparacion:{trabajo.calcular_costo_total()}\n")

    def modificar_sueldo_mecanico(self):
        try:
            rut_mecanico = input("Ingrese el RUT del mecánico cuyo sueldo desea modificar: ")
            nuevo_honorario = int(input("Ingrese el nuevo Honorario el Mecanico $: "))
        except ValueError:
            print("Ingrese Solamente Numeros! \nIntentelo De Nuevo")
            return

        mecanico = self.__crud_mecanico.buscar_mecanico(rut_mecanico)
        if mecanico:
            self.__crud_mecanico.modificar_sueldo(rut_mecanico, nuevo_honorario)
            print(f"¡Sueldo del RUT : {rut_mecanico} Del Mecanico modificado con éxito!")
        else:
            print(f"No se encontró un mecánico con el RUT {rut_mecanico}\nIntentelo De Nuevo")

    def eliminar_mecanico(self):
        try:
            rut_eliminar = input("Ingrese el RUT del mecánico que desea eliminar: ")
            mecanico_existente = self.__crud_mecanico.buscar_mecanico(rut_eliminar)
        except ValueError:
            print("ERROR: Ingrese Datos Numericos\n Intentelo De Nuevo")
            return

        if mecanico_existente:
            confirmacion = input(f"¿Está seguro de que desea eliminar al mecánico con RUT {rut_eliminar}? (SI/NO)\n ").lower()
            if confirmacion == 'si':
                self.__crud_mecanico.eliminar_mecanico(rut_eliminar)
                print("Mecánico eliminado con éxito.")
            else:
                print("Operación cancelada.")
        else:
            print(f"No se encontró un mecánico con el RUT {rut_eliminar}.")


class Main:
    def __init__(self):
        self.__mecanicos = []
        self.__vehiculos = []
        self.__trabajos = []



    def obtener_mecanicos(self):
        return self.__mecanicos
    
    def encontrar_mecanicos(self, nombre):
        for mecanico in self.__mecanicos:
            if mecanico.conseguir_nombre() == nombre:
                return mecanico
    
    def encontrar_vehiculos(self, patente):
        for vehiculo in self.__vehiculos:
            if vehiculo.obtener_patente() == patente:
                return vehiculo

    
    def agregar_reparaciones(self, reparacion):
        self.__trabajos.append(reparacion)

    def obtener_reparaciones(self):
        return self.__trabajos

    def obtener_vehiculos(self):
        return self.__vehiculos
    
    def agregar_vehiculo(self, vehiculo):
        self.__vehiculos.append(vehiculo)
    
    def obtener_trabajos(self):
        return self.__trabajos
    
Menu().iniciar()