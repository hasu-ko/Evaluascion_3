import hashlib

class Rol:
    def __init__(self, id, nombre_rol, descripcion):
        self.__id_rol = id
        self.__nombre_rol = nombre_rol
        self.__descripcion = str()
        

    def obtener_id(self):
        return self.__id_rol
    
    def obtener_nombre_rol(self):
        return self.__nombre_rol
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def cambiar_descripcion(self, descripcion):
        self.__descripcion = descripcion

class Usuario:
    def __init__(self, nombre, clave, rol, rut):
        self.__nombre = nombre
        self.__clave = clave
        self.__rol = rol
        self.__mecanico = None
        self.__rut = rut


    def obtener_nombre(self):
        return self.__nombre

    def obtener_rol(self):
        return self.__rol
    
    def obtener_clave(self):
        return self.__clave

    def obtener_mecanico(self):
        return self.__mecanico
    
    def obtener_rut(self):
        return self.__rut

    def validar_clave(self, clave):
        enc = clave.encode()
        hash = hashlib.md5(enc).hexdigest()
        return self.__clave == hash

    def cambiar_clave(self, clave):
        enc = clave.encode()
        hash = hashlib.md5(enc).hexdigest()
        self.__clave = hash

    def asignar_mecanico(self, mecanico):
        self.__mecanico = mecanico


class Persona:
    def __init__(self, rut, nombre, apellido):
        self.__rut = rut
        self.__nombre = nombre
        self.__apellido = apellido
    
    def obtener_nombre(self):
        return self.__nombre

    def obtener_apellido(self):
        return self.__apellido
    
    def obtener_rut(self):
        return self.__rut
    
class Cliente(Persona):
    def __init__(self, rut, nombre, apellido, telefono):
        super().__init__(rut, nombre, apellido)
        self.__telefono = telefono

    def obtener_telefono(self):
        return self.__telefono
    
    def colocar_telefono(self, telefono):
        self.__telefono = telefono
    
    def agregar_vehiculo(self, vehiculo):
        self.__vehiculos.append(vehiculo)
    
    def remover_vehiculo(self, vehiculo):
        self.__vehiculos.remove(vehiculo)

class Mecanico(Persona):
    def __init__(self, rut, nombre, apellido, honorario):
        super().__init__(rut, nombre, apellido)
        self.__honorario = honorario
    
    def obtener_honorario(self):
        return self.__honorario
    
    def set_honorario(self, honorario):
        self.__honorario = honorario


class Trabajo:
    def __init__(self, fecha_inicio, fecha_entrega, estado_inicial, detalles_reparacion, costo_total_repuestos, mecanicos, vehiculos):
        self.__fecha_inicio = fecha_inicio
        self.__fecha_entrega = fecha_entrega
        self.__estado_inicial = estado_inicial
        self.__detalles_reparacion = detalles_reparacion
        self.__costo_total_repuestos = costo_total_repuestos
        self.__mecanicos = mecanicos
        self.__vehiculo = vehiculos

    def obtener_fecha_inicio(self):
        return self.__fecha_inicio
    
    def obtener_fecha_entrega(self):
        return self.__fecha_entrega
    
    def obtener_estado_inicial(self):
        return self.__estado_inicial
    
    def obtener_detalles_reparaciones(self):
        return self.__detalles_reparacion
    
    def obtener_costo_total_reparaciones(self):
        return self.__costo_total_repuestos
    
    def obtener_mecanicos(self):
        return self.__mecanicos
    
    
    def obtener_vehiculos(self):
        return self.__vehiculo
    
    def colocar_fecha_entraga(self, fecha_entrega):
        self.__fecha_entrega = fecha_entrega

    def agregar_mecanico(self, mecanicos):
        self.__mecanicos.append(mecanicos)
    
    def remover_mecanico(self, mecanicos):
        self.__mecanicos.remove(mecanicos)

    def asignar_vehiculo(self, vehiculo):
        self.__vehiculo = vehiculo
    
    def calcular_costo_total(self):
        costo_repuestos = self.__costo_total_repuestos
        honorarios_mecanicos = sum(mecanico.obtener_honorario() 
        for mecanico in self.obtener_mecanicos())
        costo_total = costo_repuestos + honorarios_mecanicos
        costo_total_con_factor = costo_total * 1.23
        return costo_total_con_factor
    
class Vehiculo():
    def __init__(self, patente, marca, modelo, año,rut):
        self.__patente = patente
        self.__marca = marca
        self.__modelo = modelo
        self.__año = año
        self.__rut = rut


    def obtener_patente(self):
        return self.__patente
    
    def obtener_marca(self):
        return self.__marca
    
    def obtener_modelo(self):
        return self.__modelo
    
    def obtener_año(self):
        return self.__año

    def obtener_rut(self):
        return self.__rut
    
    def obtener_telefono(self):
        return self.__telefono
    



    
