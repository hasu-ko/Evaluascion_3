DROP DATABASE IF EXISTS taller_mecanico_db;
CREATE DATABASE taller_mecanico_db;
USE taller_mecanico_db;

DROP TABLE IF EXISTS mecanico;
CREATE TABLE mecanico (
    rut_mecanico VARCHAR(10) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    honorario INT
);

DROP TABLE IF EXISTS cliente;
CREATE TABLE cliente (
    rut_cliente VARCHAR(10) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    telefono VARCHAR(9)
);

DROP TABLE IF EXISTS vehiculo;
CREATE TABLE vehiculo (
    patente_vehiculo VARCHAR(10) PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50),
    año INT(4),
    rut_cliente VARCHAR(10) NOT NULL,
    FOREIGN KEY (rut_cliente) REFERENCES cliente (rut_cliente)
);

DROP TABLE IF EXISTS trabajo;
CREATE TABLE trabajo (
    id_trabajo INT AUTO_INCREMENT PRIMARY KEY,
    fecha_ingreso DATE NOT NULL,
    fecha_entrega DATE,
    estado TEXT,
    reparaciones TEXT,
    patente_vehiculo VARCHAR(10) NOT NULL,
    FOREIGN KEY (patente_vehiculo) REFERENCES vehiculo (patente_vehiculo)
);

DROP TABLE IF EXISTS mecanicos_trabajo;
CREATE TABLE mecanicos_trabajo (
    rut_mecanico VARCHAR(10) NOT NULL,
    id_trabajo INT NOT NULL,
    PRIMARY KEY (rut_mecanico, id_trabajo),
    FOREIGN KEY (rut_mecanico) REFERENCES mecanico (rut_mecanico),
    FOREIGN KEY (id_trabajo) REFERENCES trabajo (id_trabajo)
);

DROP TABLE IF EXISTS rol;
CREATE TABLE rol(
id_rol int auto_increment primary key,
nombre_rol varchar(50),
descripcion varchar(100)
);

create table if not exists usuario (
nombre_usuario varchar(15) primary key,
clave varchar(32) not null,
id_rol int not null,
rut_mecanico varchar(10),
foreign key (id_rol) references rol (id_rol),
foreign key (rut_mecanico) references mecanico (rut_mecanico),
unique key (rut_mecanico)
);

insert into mecanico (rut_mecanico, nombre, apellido, honorario) VALUES ('533-2', 'Juan', 'Perez', 1000);

insert into mecanico (rut_mecanico, nombre, apellido, honorario) VALUES ('233-5', 'Angel', 'ch', '1500');

insert into rol (nombre_rol, descripcion) VALUES ('Administrador', 'Encargado de administrar el sistema');
insert into rol (nombre_rol, descripcion) VALUES ('Secretaria', 'Encargada de recepcionar clientes');
insert into rol (nombre_rol, descripcion) VALUES ('Mecanico', 'Encargado de reparacion de autos');

-- insercion de datos en USUARIO
insert into usuario VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 1, null);
insert into usuario VALUES ('secre', 'c27fcccb5a5ad952f378481c86a84c3a', 2, null);
insert into usuario VALUES ('mecan', '655c0ea8c5384647d3c49f760283575b', 3, '533-2');
COMMIT;

select * from usuario join rol using(id_rol);
SELECT u.nombre_usuario, u.clave, u.id_rol, u.rut_mecanico, r.nombre_rol, r.descripcion
FROM usuario u
JOIN rol r ON u.id_rol = r.id_rol;
