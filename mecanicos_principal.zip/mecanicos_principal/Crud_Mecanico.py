import mysql.connector
from mysql.connector.errors import IntegrityError
from clases_mecanicos import *


class CrudRol:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = '',
            database = 'taller_mecanico_db')
        
    def mostrar_rol(self):
        cursor = self.conexion.cursor()
        sql = 'select * from rol'
        cursor.execute(sql)
        result = cursor.fetchall()
        roles = []

        for row in result:
            rol = Rol(id=row[0], nombre_rol=row[1], descripcion=row[2])
            rol.cambiar_descripcion(descripcion=row[2])
            roles.append(rol)

        return roles
    
    def buscar_rol(self, id):
        cursor = self.conexion.cursor()
        sql = 'select * from rol where id_rol=%s'
        val = (id,)
        cursor.execute(sql, val)
        row = cursor.fetchone()
        if row is not None:
            rol = Rol(id=row[0], nombre_rol=row[1], descripcion=row[2])
            rol.cambiar_descripcion(descripcion=row[2])
            return rol
        else:
            return None

class CrudUsuario:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = '',
            database = 'taller_mecanico_db')

    def crear_usuario(self, usuario: Usuario, clave: str):
        try:
            hash_clave = hashlib.md5(clave.encode()).hexdigest()
            cursor = self.conexion.cursor()
            sql = 'INSERT INTO usuario VALUES (%s, %s, %s, %s, %s, %s)'
            val = (
                usuario.obtener_nombre_usuario(),
                hash_clave,
                usuario.obtener_nombre(),
                usuario.obtener_apellido(),
                usuario.obtener_rol().obtener_id(),
                usuario.obtener_mecanico().obtener_rut() if usuario.obtener_mecanico() else None
            )
            print("Valores antes de la insercion:", val)
            cursor.execute(sql, val)
            self.conexion.commit()
            print("Usuario creado correctamente.")
        except mysql.connector.Error as err:
            print(f"Error al crear el usuario: {err}")


    def obtener_id_rol_por_nombre(self, nombre_rol):
        query = "SELECT id_rol FROM rol WHERE nombre_rol = %s"
        try:
            with self.conexion.cursor() as cursor:
                cursor.execute(query, (nombre_rol,))
                result = cursor.fetchone()
                if result:
                    return result[0]
                else:
                    return None
        except Exception as e:
            print(f"Error al obtener el id_rol: {e}")
            return None

    
    def buscar_usuario(self, nombre):
        cursor = self.conexion.cursor()
        sql = 'select nombre_usuario, clave, id_rol, rut_mecanico from usuario join rol using (id_rol) where nombre_usuario=%s'
        val = (nombre,)
        cursor.execute(sql, val)
        row = cursor.fetchone()
        if row is not None:
            crud = CrudRol()
            rol = crud.buscar_rol(id=row[2])
            usuario = Usuario(nombre=row[0], clave=row[1], rol=rol, rut=row[3])
            if row[3] is not None:
                crud = CrudMecanico()
                vet = crud.buscar_mecanico(rut=row[3])
                usuario.asignar_mecanico(vet)
            return usuario
        else:
            return None

    def crear_usuario(self, usuario, clave):
        hash_clave = hashlib.md5(clave.encode()).hexdigest()
        cursor = self.conexion.cursor()

        try:
            sql = '''
                INSERT INTO usuario (nombre_usuario, clave, id_rol, rut_mecanico)
                SELECT %s, %s, r.id_rol, NULL
                FROM rol r
                INNER JOIN usuario u ON r.id_rol = u.id_rol
                WHERE r.nombre_rol = %s
            '''
            val = (usuario.obtener_nombre(), hash_clave, usuario.obtener_rol().obtener_nombre_rol())
            cursor.execute(sql, val)
            self.conexion.commit()
            print("Usuario creado exitosamente.")
        except Exception as e:
            print(f"Error al crear el usuario: {e}")
        finally:
            cursor.close()
        self.conexion.commit()

    def obtener_usuarios(self):
        usuarios = []
        cursor = self.conexion.cursor()
        sql = 'SELECT u.nombre_usuario, u.clave, u.id_rol, u.rut_mecanico, r.nombre_rol, r.descripcion, m.nombre AS nombre_mecanico, m.apellido AS apellido_mecanico FROM usuario u JOIN rol r ON u.id_rol = r.id_rol LEFT JOIN mecanico m ON u.rut_mecanico = m.rut_mecanico'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            usuario = self.buscar_usuario(nombre=row[0])
            usuarios.append(usuario)
        return usuarios
    
    def eliminar_usuario_por_rut(self, rut):
        cursor = self.conexion.cursor()
        usuario_existente = self.buscar_usuario_por_rut(rut)
        if usuario_existente:
            sql = 'DELETE FROM usuario WHERE rut_mecanico = %s'
            val = (rut,)
            cursor.execute(sql, val)
            self.conexion.commit()
            print(f'Usuario con RUT {rut} eliminado exitosamente.')
        else:
            print(f'Error: No se encontró un usuario con el RUT {rut}.')

    def buscar_usuario_por_rut(self, rut):
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM usuario WHERE rut_mecanico = %s'
        val = (rut,)
        cursor.execute(sql, val)
        row = cursor.fetchone()

        if row is not None:
            return True
        else:
            return False
    
    def reestablecer_clave_por_rut(self, rut, nueva_clave):
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM usuario WHERE rut_mecanico = %s'
        cursor.execute(sql, (rut,))
        usuario = cursor.fetchone()
        if usuario:
            sql_update = 'UPDATE usuario SET clave = %s WHERE rut_mecanico = %s'
            cursor.execute(sql_update, (hashlib.md5(nueva_clave.encode()).hexdigest(), rut))
            self.conexion.commit()
            return True
        else:
            return False

class CrudMecanico:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = '',
            database = 'taller_mecanico_db'
        )

    def obtener_mecanico(self):
        mecanicos = []
        cursor = self.conexion.cursor()
        sql = 'select * from mecanico'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            mec = Mecanico(rut = row[0],nombre = row[1], apellido= row[2], honorario=row[3])
            mecanicos.append(mec)
        return mecanicos
    
    def agregar_mecanicos(self, mecanico):
        cursor = self.conexion.cursor()
        try:
            sql = 'insert into mecanico values(%s, %s, %s, %s)'
            val = (mecanico.obtener_rut(), 
                  mecanico.obtener_nombre(), 
                  mecanico.obtener_apellido(), 
                  mecanico.obtener_honorario())
            cursor.execute(sql, val)
            self.conexion.commit()
            print("Mecánico agregado correctamente.")
        except IntegrityError as e:
            print(f"Error al agregar el mecánico. {e}")
            print("Llave Primaria Duplicada")

    def buscar_mecanico(self, rut):
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM mecanico WHERE rut_mecanico = %s'
        val = (rut, )
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result:
            mec = Mecanico(rut=result[0], nombre=result[1], apellido=result[2], honorario=result[3])
            return mec
        else:
            return None
        
    def modificar_sueldo(self, rut, nuevo_honorario):
        cursor = self.conexion.cursor()
        sql = 'UPDATE mecanico SET honorario = %s WHERE rut_mecanico = %s'
        val = (nuevo_honorario, rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        
    def eliminar_mecanico(self, rut):
        cursor = self.conexion.cursor()
        sql = 'DELETE FROM mecanico WHERE rut_mecanico = %s'
        val = (rut, )
        cursor.execute(sql, val)
        self.conexion.commit()
    
class CrudCliente:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = '',
            database = 'taller_mecanico_db'
        )

    def agregar_clientes(self, cliente):
        cursor = self.conexion.cursor()
        try:
            sql = 'insert into cliente values(%s, %s, %s, %s)'
            val = (cliente.obtener_rut(), 
                  cliente.obtener_nombre(), 
                  cliente.obtener_apellido(), 
                  cliente.obtener_telefono())
            cursor.execute(sql, val)
            self.conexion.commit()
            print("Cliente agregado correctamente.")
        except IntegrityError as e:
            print(f"Error al agregar el cliente. {e}")
            print("Llave Primaria Duplicada")

    def obtener_cliente(self):
        clientes = []
        cursor = self.conexion.cursor()
        sql = 'select * from cliente'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            cliente = Cliente(rut = row[0],nombre = row[1], apellido= row[2], telefono=row[3])
            clientes.append(cliente)
        return clientes

    def eliminar_cliente(self, rut):
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM cliente WHERE rut_cliente = %s'
            val = (rut, )
            cursor.execute(sql, val)
            self.conexion.commit()
            print("Cliente eliminado correctamente.")
        except IntegrityError as e:
            print(f"Error al eliminar el cliente. {e}")
            print("Asegúrate de que no hay referencias a este cliente en otras tablas.")

    def buscar_cliente(self, rut):
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM cliente WHERE rut_cliente = %s'
        val = (rut, )
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result:
            mec = Cliente(rut=result[0], nombre=result[1], apellido=result[2], telefono=result[3])
            return mec
        else:
            return None

    def modificar_telefono(self, rut, telefono_nuevo):
        cursor = self.conexion.cursor()
        sql = 'UPDATE cliente SET telefono = %s WHERE rut_cliente = %s'
        val = (telefono_nuevo, rut)
        cursor.execute(sql, val)
        self.conexion.commit()
    
class CrudVehiculo:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host = 'localhost',
            user = 'root',
            password = '',
            database = 'taller_mecanico_db'
        )

    def crear_vehiculo(self,Vehiculo):
        cursor = self.conexion.cursor()
        try:
            sql = 'insert into vehiculo values(%s, %s, %s, %s,%s)'
            val = (Vehiculo.obtener_patente(), 
                  Vehiculo.obtener_marca(), 
                  Vehiculo.obtener_modelo(), 
                  Vehiculo.obtener_año(),
                  Vehiculo.obtener_rut())

            

            cursor.execute(sql, val)
            self.conexion.commit()
            print("Vehiculo agregado correctamente.")
        except IntegrityError as e:
            print(f"Error al agregar el Vehiculo. {e}")
            print("Llave Primaria Duplicada")

    def buscar_vehiculo(self, patente):
        cursor = self.conexion.cursor()
        try:
            sql = 'SELECT * FROM vehiculo WHERE patente_vehiculo = %s'
            val = (patente,)
            cursor.execute(sql, val)
            result = cursor.fetchone()
            if result:
                vehiculo = Vehiculo(
                    patente=result[0],
                    marca=result[1],
                    modelo=result[2],
                    año=result[3],
                    rut=result[4]
                )
                return vehiculo
            else:
                return None
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))

    def obtener_vehiculos(self):
        vehiculos=[]
        cursor = self.conexion.cursor()
        sql = 'select patente_vehiculo,marca,modelo,año,A.rut_cliente,B.nombre from vehiculo as A,cliente AS B where A.rut_cliente=B.rut_cliente '
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            vehiculos.append(row)
        return vehiculos
    
    def eliminar_vehiculo(self, patente):
        try:
            cursor = self.conexion.cursor()
            sql = 'DELETE FROM vehiculo WHERE patente_vehiculo = %s'
            val = (patente,)
            cursor.execute(sql, val)
            self.conexion.commit()
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))
        
class CRUDTrabajo:
    def init(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='taller_mecanico_db')

    def listar_trabajos(self):
        try:
            trabajos = []
            cursor = self.conexion.cursor()
            sql = 'SELECT * FROM trabajo'
            cursor.execute(sql)
            result = cursor.fetchall()
            for row in result:
                trabajo = Trabajo(
                    fecha_inicio=row[1],
                    fecha_entrega=row[2],
                    estado_inicial=row[3],
                    detalles_reparacion=row[4],
                    costo_total_repuestos=row[5],
                    mecanicos=[], 
                    vehiculos=[]    
                )
                trabajos.append(trabajo)
            return trabajos
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))
        
    def buscar_trabajo(self, id_trabajo):
        try:
            cursor = self.conexion.cursor()
            sql = '''
                SELECT 
                    T.*, 
                    C.rut_cliente, C.nombre AS nombre_cliente, C.apellido AS apellido_cliente, C.telefono AS telefono_cliente,
                    V.patente_vehiculo, V.marca AS marca_vehiculo, V.modelo AS modelo_vehiculo, V.año AS año_vehiculo,
                    MT.rut_mecanico
                FROM trabajo T
                JOIN vehiculo V ON T.patente_vehiculo = V.patente_vehiculo
                JOIN cliente C ON V.rut_cliente = C.rut_cliente
                LEFT JOIN mecanicos_trabajo MT ON T.id_trabajo = MT.id_trabajo
                WHERE V.patente_vehiculo = %s
            '''
            cursor.execute(sql, (patente_vehiculo,))
            result = cursor.fetchone()

            if result:
                # Datos del trabajo
                id_trabajo = result[0]
                fecha_inicio = result[1]
                fecha_entrega = result[2]
                estado_inicial = result[3]
                detalles_reparacion = result[4]
                costo_total_repuestos = result[5]

                # Datos del cliente
                rut_cliente = result[6]
                nombre_cliente = result[7]
                apellido_cliente = result[8]
                telefono_cliente = result[9]

                # Datos del vehículo
                patente_vehiculo = result[10]
                marca_vehiculo = result[11]
                modelo_vehiculo = result[12]
                año_vehiculo = result[13]

                # Datos del mecanico (puede ser None si no hay mecanico asignado)
                rut_mecanico = result[14]

                # Crear instancias de las clases Cliente, Vehiculo y Trabajo
                cliente = Cliente(rut=rut_cliente, nombre=nombre_cliente, apellido=apellido_cliente, telefono=telefono_cliente)
                vehiculo = Vehiculo(patente=patente_vehiculo, marca=marca_vehiculo, modelo=modelo_vehiculo, año=año_vehiculo, rut=rut_cliente)

                # Crear instancia de la clase Trabajo y asignar los valores correspondientes
                trabajo = Trabajo(
                    id_trabajo=id_trabajo,
                    fecha_inicio=fecha_inicio,
                    fecha_entrega=fecha_entrega,
                    estado_inicial=estado_inicial,
                    detalles_reparacion=detalles_reparacion,
                    costo_total_repuestos=costo_total_repuestos,
                    mecanicos=[],  # Puedes ajustar esto según tu lógica
                    vehiculos=vehiculo
                )

                return trabajo
            else:
                return None

        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))
        
class CRUDTrabajo:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='taller_mecanico_db')

    def listar_trabajos(self):
        try:
            trabajos = []
            cursor = self.conexion.cursor()
            sql = '''
                SELECT 
                    T.*, 
                    C.rut_cliente, C.nombre AS nombre_cliente, C.apellido AS apellido_cliente, C.telefono AS telefono_cliente,
                    V.patente_vehiculo, V.marca AS marca_vehiculo, V.modelo AS modelo_vehiculo, V.año AS año_vehiculo,
                    MT.rut_mecanico
                FROM trabajo T
                JOIN vehiculo V ON T.patente_vehiculo = V.patente_vehiculo
                JOIN cliente C ON V.rut_cliente = C.rut_cliente
                LEFT JOIN mecanicos_trabajo MT ON T.id_trabajo = MT.id_trabajo
            '''
            cursor.execute(sql)
            result = cursor.fetchall()

            for row in result:
                id_trabajo = row[0]
                fecha_inicio = row[1]
                fecha_entrega = row[2]
                estado_inicial = row[3]
                detalles_reparacion = row[4]
                costo_total_repuestos = row[5]
                rut_cliente = row[6]
                nombre_cliente = row[7]
                apellido_cliente = row[8]
                telefono_cliente = row[9]
                patente_vehiculo = row[10]
                marca_vehiculo = row[11]
                modelo_vehiculo = row[12]
                año_vehiculo = row[13]
                rut_mecanico = row[14]
                cliente = Cliente(rut=rut_cliente, nombre=nombre_cliente, apellido=apellido_cliente, telefono=telefono_cliente)
                vehiculo = Vehiculo(patente=patente_vehiculo, marca=marca_vehiculo, modelo=modelo_vehiculo, año=año_vehiculo, rut=rut_cliente)
                trabajo = Trabajo(
                    fecha_inicio=fecha_inicio,
                    fecha_entrega=fecha_entrega,
                    estado_inicial=estado_inicial,
                    detalles_reparacion=detalles_reparacion,
                    costo_total_repuestos=costo_total_repuestos,
                    mecanicos=[],
                    vehiculos=vehiculo
                )

                trabajos.append(trabajo)

            return trabajos

        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))


    def crear_trabajo(self, trabajo):
        try:
            cursor = self.conexion.cursor()
            sql = 'INSERT INTO trabajo (fecha_ingreso, fecha_entrega, estado, reparaciones, patente_vehiculo) VALUES (%s, %s, %s, %s, %s)'
            vals = (
                trabajo.obtener_fecha_inicio(),
                trabajo.obtener_fecha_entrega(),
                trabajo.obtener_estado_inicial(),
                trabajo.obtener_detalles_reparaciones(),
                trabajo.obtener_vehiculos().obtener_patente()
            )
            cursor.execute(sql, vals)
            self.conexion.commit()
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))

    def buscar_trabajo(self, id_trabajo):
        try:
            cursor = self.conexion.cursor()
            sql = 'SELECT * FROM trabajo WHERE id_trabajo = %s'
            val = (id_trabajo,)
            cursor.execute(sql, val)
            result = cursor.fetchone()
            if result is not None:
                trabajo = Trabajo(
                    fecha_inicio=result[1],
                    fecha_entrega=result[2],
                    estado_inicial=result[3],
                    detalles_reparacion=result[4],
                    costo_total_repuestos=result[5],
                    mecanicos=[],  
                    vehiculos=[]    
                )
                return trabajo
            else:
                return None
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))

    def agregar_mecanico(self, id_trabajo, rut_mecanico):
        try:
            cursor = self.conexion.cursor()
            sql = 'INSERT INTO mecanicos_trabajo VALUES (%s, %s)'
            vals = (rut_mecanico, id_trabajo)
            cursor.execute(sql, vals)
            self.conexion.commit()
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))

    def cambiar_estado_reparaciones(self, id_trabajo, nuevo_estado, nuevas_reparaciones):
        try:
            cursor = self.conexion.cursor()
            sql = 'UPDATE trabajo SET estado = %s, reparaciones = %s WHERE id_trabajo = %s'
            vals = (nuevo_estado, nuevas_reparaciones, id_trabajo)
            cursor.execute(sql, vals)
            self.conexion.commit()
        except mysql.connector.Error as err:
            raise Exception('Error de base de datos: {}'.format(err))
