import maskpass
from Crud_Mecanico import *
from clases_mecanicos import * 

nombre = input('Ingrese el nombre de usuario: ')
clave = maskpass.askpass('Ingrese la clave: ')
crud = CrudUsuario()
usuario = crud.buscar_usuario(nombre)
if usuario is not None:
    if usuario.validar_clave(clave):
        print('Bienvenido {} ({})!'.format(
            usuario.obtener_nombre(),
            usuario.obtener_rol().obtener_nombre()
        ))
        id_rol = usuario.obtener_rol().obtener_id()
        if id_rol == 1:
            while(True):
                print('Menu de administrador')
                print('1. Mostrar usuarios')
                print('2. Crear usuario')
                print('3. Salir')
                opc = int(input('Ingrese su opcion: '))
                if opc == 1:
                    for u in crud.obtener_usuarios():
                        print('Nombre:{} Rol:{} Mecanico?:{}'.format(
                            u.obtener_nombre(),
                            u.obtener_rol().obtener_nombre(),
                            u.obtener_mecanico() is not None
                        ))
                elif opc == 2:
                    nombre = input('Ingrese el nombre: ')
                    clave = maskpass.askpass('Ingrese la clave: ')
                    id_rol = int(input('Ingrese el rol (1=Admin 2=Secre, 3=Vet): '))
                    crud2 = CrudRol()
                    rol = crud2.buscar_rol(id_rol)
                    nuevo_usuario = Usuario(nombre, clave, rol)
                    if crud.crear_usuario(nuevo_usuario, clave):
                        print('Usuario creado!')
                elif opc == 3:
                    break
                else:
                    print('Opción no valida!')
        elif id_rol == 2:
            print('Menu de secretaria')
        else:
            print('Datos del veterinario')
            print('Nombre: {} Apellido:{} Especialidad:{}'.format(
                usuario.obtener_veterinario().obtener_nombre(),
                usuario.obtener_veterinario().obtener_apellido(),
                usuario.obtener_veterinario().obtener_especialidad()
            ))
            print('Presione ENTER para salir')
            input()
    else:
        print('La clave no es valida!')
else:
    print('El nombre de usuario no es valido!')