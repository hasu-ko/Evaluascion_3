import maskpass
import hashlib

def cifrar_clave(clave):
    enc = clave.encode()
    hash = hashlib.md5(enc).hexdigest()
    return hash

mi_clave = maskpass.askpass('Ingrese su clave: ', mask='**')
mi_hash = cifrar_clave(mi_clave)
print('La clave en claro es: {}'.format(mi_clave))
print('La clave cifrada es: {}'.format(mi_hash))
print('El tamaño de clave cifrada es: {}'.format(len(mi_hash)))